/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.slcc.asdv.bl;

import java.sql.Connection;
import java.util.List;

/**
 *
 * 
 */
public interface Database {

    /**
     *
     * @param databaseName name
     * @param userName database user name
     * @param passord database password
     * @param driver driver that connects us to database
     * @return Connection the connection to databas or null if no connection
     */
    public Connection getConnection(String databaseName, String userName, String password, String driver);
    
    /**
     *
     * @param tableName the name of the table to return
     * @return a list with all rows in the table
     */
    public List<String> selectAllFromTable(String tableName);
    
    /**
     *
     * @param tableName the name of the table
     * @return true if the table exists in the database, false otherwise
     */
    boolean isTable(  String tableName);
    
    /**-----------------------------------------------------------------------------------------------Implement this for HW
     *
     * @param tableName
     * @param fields key of one or more attributes 
     * @return a list with all the rows for a specific table 'tablename; where all fields match the 
     * database fields are equal
     */
    public List<String> selectAlllFromTableWhereFieldAreEqual(String tableName, String fields);
    
    
    
    //-------------------------------------------------------------------------------------------------------
    
    /**
     *
     * @param c the connection to close
     */
    public void closeConnection(Connection c);
}
